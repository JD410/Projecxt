﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class signup : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\myshopping.mdf;Integrated Security=True;User Instance=True");

    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }
    protected void btnregister_Click(object sender, EventArgs e)
    {
       
    }
    protected void Unnamed1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into tblsignup values('" + txtuser.Text + "','" + txtmail.Text + "','" + txtpasswd.Text + "')", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        int a = da.Fill(dt);
        if (a == 0)
        {
            Response.Write("Data Inserted");

        }
        else
        {
            Response.Write("Data Not Inserted");
        }
    }
}